const mongoose = require('mongoose')

const {Schema} = mongoose;

const nowSchema = new Schema({
    name: String,
    count: Number,
    power: Number,
    pressure: Number,
    run: Number,
    status: Number,
    temperature: Number,
    timestamp: Date,
    availability: Number,
    start_time: Date
})

const Now = mongoose.model('Now', nowSchema);

module.exports = Now;