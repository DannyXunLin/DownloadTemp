const mongoose = require("mongoose");

const dataSchema = new mongoose.Schema({
  name: String,
  power: Number,
  run: Number,
  status: Number,
  count: Number,
  temperature: Number,
  pressure: Number,
  timestamp: Date,
  availability: Number,
  start_time: Date,
  fail: Number,
  cycle_time: Number
});

const Data = mongoose.model("Data", dataSchema);

module.exports = Data;