const mongoose = require('mongoose')

const {Schema} = mongoose;

const reportSchema = new Schema({
    name: {
        type: String,
        required: true
    },
    start_time: {
        type: Date,
        required: true
    },
    end_time: Date,
});

const Report = mongoose.model('Report', reportSchema);

module.exports = Report;