const mongoose = require('mongoose')

const {Schema} = mongoose;

const errorSchema = new Schema({
    name: String,
    timestamp: Date,
    error: String
})

const Error = mongoose.model('Error', errorSchema);

module.exports = Error;