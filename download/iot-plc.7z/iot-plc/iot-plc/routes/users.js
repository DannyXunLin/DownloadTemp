var express = require('express');
const User = require("../models/user");
var router = express.Router();
const bcrypt = require('bcrypt');

/* GET users listing. */
router.get('/', async (req, res, next) => {
    const userList = await User.find();
    res.render('userList', {user: userList});
});

router.get('/adduser', async (req, res, next) => {
    res.render('userForm', {permissions: []})
})

router.post('/adduser', async (req, res, next) => {
    const data = req.body;
    console.log(data)
    const salt = await bcrypt.genSalt(12);
    data.password = await bcrypt.hash(data.password, salt)
    const user = new User(data);
    await user.save();

    res.status(201).redirect('/admin');
})

router.get('/edituser/:Id', async (req, res) => {
    const user = await User.findById(req.params['Id'])
    res.render('userForm', user)
});

router.post('/edituser/:Id', async (req, res) => {
    const data = req.body;
    console.log(data)
    if (data.password === '') {
        await User.findByIdAndUpdate(req.params['Id'], {
            $set: {
                name: data.name, last_name: data.last_name,
                first_name: data.first_name, permissions: data.permissions
            }
        }).then(() => {
            res.redirect('/admin');
        }).catch((err) => res.status(500).send(err.message))
    } else {
        const salt = await bcrypt.genSalt(12);
        data.password = await bcrypt.hash(data.password, salt)
        await User.findByIdAndUpdate(req.params['Id'], {
            $set: {
                name: data.name, last_name: data.last_name, first_name: data.first_name,
                password: data.password, permissions: data.permissions
            }
        }).then(() => {
            res.redirect('/admin');
        }).catch((err) => res.status(500).send(err.message))
    }
});

module.exports = router;
