var express = require('express');
var router = express.Router();
const mongoose = require('mongoose');
const jwt = require("jsonwebtoken");
// 載入.env文件
const dotenv = require("dotenv")
dotenv.config()
// UUID
const {v4: uuidv4} = require("uuid");
const axios = require('axios')

const Now = require('../models/now')
const Error = require('../models/error')
const errorWrapper = require("../utils/errorWrapper");
const fs = require("fs");
const permissionCheck = require('../utils/permissionCheck')
const Report = require('../models/report')
const Data = require("../models/data");


//Models

/* GET home page. */

// Swagger
// https://www.npmjs.com/package/mongoose-to-swagger

router.get('/test', async (req, res) => {
    const data = await Now.findOne({"name": "A001"})
    console.log(data)
    return res.status(200).json(data)
})

router.get('/ws', async (req, res) => {
    // Define a WebSocket route (for example purposes, just a route that sends a message)
    return res.send('Message sent to all WebSocket clients');
})

router.post('/line', errorWrapper(async (req, res) => {
    const {pwd, msg} = req.body
    console.log(pwd)
    console.log(msg)
    // 修改请求体
    const modifiedBody = new FormData();
    modifiedBody.append('message', msg);
    if (pwd !== 'ttt928') {
        return res.status(401).send()
    } else {
        console.log(modifiedBody)
        const token = process.env.LINE_TOKEN
        const response = await axios.post('https://notify-api.line.me/api/notify', modifiedBody, {
            headers: {
                'Authorization': `Bearer ${token}`, // 如果是使用 Bearer token 认证
            }
        }).then((res) => console.log(res.data));

        return res.status(200).send()
    }
}))

// router.get('/')

// 生產報表
router.get('/report', errorWrapper(async (req, res) => {
    const data = await Report.find()
    return res.status(200).json(data)
}))

// 生產報表
router.post('/report', errorWrapper(async (req, res) => {
    const {...body} = req.body;
    console.log(body)
    let filter = {}
    if(body.name !== undefined && body.name !== ''){
        filter.name = body.name
    }
     if (body.start !== null && body.start !== undefined && body.start !== '') {
         filter.start_time = {}
         filter.start_time.$gte = new Date(body.start.toString() + '+00:00')
     }
    if (body.end !== null && body.end !== undefined && body.end !== '') {
        filter.start_time.$lte = new Date(body.end.toString() + '+00:00')
    }
    console.log(filter)
    const data = await Report.find(filter);
    return res.status(200).json(data)
}))

// 機器現況
router.get('/now', errorWrapper(async (req, res) => {
    const data = await Now.find()
    return res.status(200).json(data)
}))

// 機器錯誤
router.get('/error', errorWrapper(async (req, res) => {
    const data = await Error.find().limit(8)
    return res.status(200).json(data)
}))

router.post('/error', errorWrapper(async (req, res) => {
    const {...body} = req.body;
    console.log(body)
    let filter = {}
    if(body.name !== undefined && body.name !== ''){
        filter.name = body.name
    }
     if (body.start !== null && body.start !== undefined && body.start !== '') {
         filter.timestamp = {}
         filter.timestamp.$gte = new Date(body.start.toString() + '+00:00')
     }
    if (body.end !== null && body.end !== undefined && body.end !== '') {
        filter.timestamp.$lte = new Date(body.end.toString() + '+00:00')
    }
    console.log(filter)
    const data = await Error.find(filter).limit(8);
    return res.status(200).json(data)
}))

//工時
router.get('/worktime', errorWrapper(async (req,res) => {
    let totalDurationInHours = 0;
    const data = await Report.aggregate([
      {
        $match: {
          start_time: { $exists: true },
          end_time: { $exists: true }
        }
      },
      {
        $project: {
          duration: { $subtract: ["$end_time", "$start_time"] }
        }
      },
      {
        $group: {
          _id: null,
          totalDuration: { $sum: "$duration" }
        }
      }
    ]);
    console.log(data)
    if(data.length > 0){
        const totalDurationInSeconds = data[0].totalDuration / 1000;
        const totalDurationInMinutes = totalDurationInSeconds / 60;
        totalDurationInHours = totalDurationInMinutes / 60;
    }
    else totalDurationInHours = 0;
    return res.status(200).json({'time': totalDurationInHours})
}))

// 取得連續資料
router.post('/data', errorWrapper(async (req, res) => {
    const {...body} = req.body;
    if(body.name === '' || body.name === undefined) return res.status(400)
    // 計算七天前的日期
    const sevenDaysAgo = new Date();
    sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);

    // 查詢 timestamp 在最近七天內的資料
    const data = await Data.aggregate([
      {
        $match: {
          timestamp: { $gte: sevenDaysAgo }, // 過濾出近七天的資料
            name: body.name
        }
      },
      {
        $group: {
          _id: {
            year: { $year: "$timestamp" },
            month: { $month: "$timestamp" },
            day: { $dayOfMonth: "$timestamp" },
            hour: { $hour: "$timestamp" }
          },
          maxCount: { $max: "$count" },           // 找到每小時的最大 count
          maxAvailability: { $max: "$availability" } // 找到每小時的最大 availability
        }
      },
      {
        $sort: { "_id.year": 1, "_id.month": 1, "_id.day": 1, "_id.hour": 1 } // 按時間排序
      }
    ]);
    return res.status(200).json(data)
}))

module.exports = router;