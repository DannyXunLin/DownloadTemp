var createError = require('http-errors');
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');
const fileUpload = require('express-fileupload');


var indexRouter = require('./routes/index');
var usersRouter = require('./routes/users');

// 載入.env文件
const dotenv = require("dotenv")
dotenv.config()
const secretKey = process.env.SECRET_KEY
const connectString = process.env.CONNECT_STRING

var app = express();
const mongoose = require('mongoose');

// WebSocket
const WebSocket = require('ws');
// Initialize WebSocket server
const wss = new WebSocket.Server({ port: 8080 });

// WebSocket event handling
wss.on('connection', async (ws) => {
  console.log('A new client connected.');
  let data;

  // Event listener for incoming messages
  ws.on('message', async (message) => {
    data = await Now.findOne({"name": message.toString()})
    // Broadcast the message to all connected clients
    wss.clients.forEach((client) => {
      if (client.readyState === WebSocket.OPEN) {
        // client.send(message.toString());
        const send = JSON.stringify(data)
        client.send(send)
      }
    });
  });

  // Event listener for client disconnection
  ws.on('close', () => {
    console.log('A client disconnected.');
  });
});

// CORS相關(需放最前面)
// CORS處理
const cors = require('cors')
const {WebSocketServer} = require("ws");
const Now = require("./models/now");
const corsOptions = {
  origin: [
    'http://bee.dmlab.live',
    'http://localhost:5173',
  ],
  methods: 'GET,HEAD,PUT,PATCH,POST,DELETE,OPTIONS',
  allowedHeaders: ['Content-Type', 'Authorization'],
};
app.use(cors(corsOptions))

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'pug');

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

// 檔案上傳
app.use(fileUpload());

// 登入驗證相關授權(不經過JWT驗證)
app.use('/admin', usersRouter);

// JWT處理(阻擋未授權)
// const {expressjwt} = require("express-jwt");
// app.use('/api', expressjwt({ secret: secretKey, algorithms: ['HS256'] }));
// app.use((req, res, next) => {
//   // 無收到token處理
//   if(req.headers.authorization === undefined && req.url.startsWith('/api')) {
//     next(createError(401))
//   }
//   next()
// })

// 路由
app.use('/api', indexRouter);

// catch 404 and forward to error handler
app.use(function(req, res, next) {
  next(createError(404));
});

// error handler
app.use(function(err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500).send(err.message);
  res.render('error');
});

// 使用mongoose連線mongodb
mongoose.connect(connectString, {dbName: 'bee'})
    .then(() => console.log('MongoDB connected'))
    .catch(err => console.log(err));

module.exports = app;
