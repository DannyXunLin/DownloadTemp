// 異步操作錯誤攔截
const errorWrapper = function (func) {

    return function (req, res, next) {

        func(req, res, next).catch(err => {
            console.log(err)
            next(err)
        });
    }
};

module.exports = errorWrapper;