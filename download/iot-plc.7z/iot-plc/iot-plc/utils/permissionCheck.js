const jwt = require("jsonwebtoken");
const permissionCheck = function (token, permission) {
    return jwt.verify(token, process.env.SECRET_KEY).permissions.includes(permission)
};

module.exports = permissionCheck;