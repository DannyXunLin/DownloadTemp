import request from "@/utils/request.js";

export function getInbox(){
    return request({
        url: '/api/doc/inbox',
        method: 'get',
    })
}

export function getUsers(){
    return request({
        url: '/api/doc/users',
        method: 'get'
    })
}

export function postDoc(data){
    return request({
        url: '/api/doc/new',
        method: 'post',
        data
    })
}

export function uploadFile(data) {
    return request({
        url: '/api/doc/upload',
        method: 'post',
        data
    }, {headers: { 'Content-Type': 'multipart/form-data' }})
}

export function getDoc(id) {
    return request({
        url: `/api/doc/view/${id}`,
        method: 'get'
    })
}

export function signDoc(data) {
    return request({
        url: `/api/doc/sign`,
        method: 'post',
        data
    })
}

export function signRejectDoc(data) {
    return request({
        url: `/api/doc/sign/reject`,
        method: 'post',
        data
    })
}

export function postSign(data){
    return request({
        url: '/api/doc/sign/add',
        method: 'post',
        data
    })
}

export function deleteSign(data) {
    return request({
        url: '/api/doc/sign/remove',
        method: 'post',
        data
    })
}

export function getSent(){
    return request({
        url: '/api/doc/sent',
        method: 'get',

    })
}

export function getDone() {
    return request({
        url: '/api/doc/done',
        method: 'get'
    })
}

export function getAll() {
    return request({
        url: '/api/doc/all',
        method: 'get'
    })
}

export function getFile(data){
    return request({
        url: '/api/doc/file',
        method: 'post',
        data,
        responseType: 'blob', // Important
    })
}

export function editDoc(data){
    return request({
        url: '/api/doc/edit',
        method: 'patch',
        data
    })
}