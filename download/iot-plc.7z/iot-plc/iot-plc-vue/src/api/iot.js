import request from "@/utils/request.js";

export function getA(){
    return request({
        url: '/api/iot/a',
        method: 'get',
    })
}

export function testLine(data){
    return request({
        url: '/line',
        method: 'post',
        data
    })
}

export function getReport() {
    return request({
        url: '/api/report',
        method: 'get'
    })
}

export function getNow() {
    return request({
        url: '/api/now',
        method: 'get'
    })
}

export function postFilterReport(data) {
    return request({
        url: '/api/report',
        method: 'post',
        data
    })
}

export function getError() {
    return request({
        url: '/api/error',
        method: 'get'
    })
}

export function postFilterError(data) {
    return request({
        url: '/api/error',
        method: 'post',
        data
    })
}

export function getWorkTime() {
    return request({
        url: '/api/worktime',
        method: 'get'
    })
}

export function postGetData(data) {
    return request({
        url: '/api/data',
        method: 'post',
        data
    })
}