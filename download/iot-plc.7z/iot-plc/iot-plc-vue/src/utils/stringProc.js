/**
 * @param {string} text
 * @param {number} max
 */
export function limitText(text, max) {
  let count = 0
  let result = ''
  if(text === undefined) return undefined

  for (let i = 0; i < text.length; i++) {
    const char = text[i]

    // 是中文就 +2 不是就 +1
    // 好像中文也可以使用+1了 原因不明
    // 除了抓 255 之外也有抓 127 的
    count += char.charCodeAt(0) > 255 ? 1 : 1
    if (count > max) break

    result += char
  }
  if(count !== text.length) result += '...'
  return result
}