export function getDateFormat(date) {
    let origin
    try{
        origin = new Date(date)
        let year = origin.getFullYear()
        let month = origin.getMonth() + 1
        let day = origin.getDate()
        if(month < 10) month = '0' + month
        if(day < 10) day = '0' + day
        return `${year}年${month}月${day}日`
    }catch{
        return null
    }
}

export function getDateTimeFormat(date) {
    let origin
    try{
        origin = new Date(date)
        let year = origin.getFullYear()
        let month = origin.getMonth() + 1
        let day = origin.getDate()
        if(month < 10) month = '0' + month
        if(day < 10) day = '0' + day
        return `${year}年${month}月${day}日 
        ${origin.getHours()<10?'0'+origin.getHours():origin.getHours()}:${origin.getMinutes()<10?'0'+origin.getMinutes():origin.getMinutes()}`
    }catch{
        return null
    }
}