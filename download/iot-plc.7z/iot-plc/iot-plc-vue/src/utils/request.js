import axios from "axios";
import {jwtDecode} from "jwt-decode";

// var URL = import.meta.env.VITE_API
var URL = import.meta.env.VITE_API

const service = axios.create({
    baseURL: URL, timeout: 6000
})

service.interceptors.request.use(async(config) => {
    const {url} = config
    // if (url.indexOf('/api') >= 0) {
    //     var jwt = localStorage.getItem('accessToken')
    //     if(jwt === null) return config
    //     const decoded = jwtDecode(jwt);
    //     const time = new Date().getTime() / 1000
    //     if (decoded.exp <= time - 6) {
    //         // 取得刷新Token
    //         let refreshToken = localStorage.getItem('refreshToken')
    //         // 呼叫API刷新Token
    //         const rs = await axios.post(`${URL}/auth/refresh`, {
    //             refreshToken
    //         });
    //         // 取得並儲存新的AccessToken
    //         const {accessToken} = rs.data;
    //         localStorage.setItem('accessToken', accessToken)
    //         jwt = accessToken;
    //     }
    //     config.headers.Authorization = 'Bearer ' + jwt
    // }
    return config
}, error => {
    Promise.reject(error).then(r => 0)
})

service.interceptors.response.use(response => {
    return response
}, error => {
    console.log(error.response.status)
    if (error.response.status === 401) {
        document.location.href = '/login/'
    }
    else if(error.response.status === 403) {
        alert('權限不足')
    }
    else{
        console.log(`Error: ${error.response.status}, ${error.response}`)
    }
    return Promise.reject(error)
})

export default service