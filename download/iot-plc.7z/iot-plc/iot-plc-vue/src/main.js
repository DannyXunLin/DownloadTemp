import 'bootstrap'
import 'bootstrap/scss/bootstrap.scss'

import { createApp } from 'vue'
import App from './App.vue'
import router from "@/routers/index.js";
import store from './store';

const app = createApp(App)

app.use(router)
app.use(store)
app.mount('#app')

