<script setup>
import {onMounted, ref} from "vue";
import {getNow, getReport, postFilterReport} from "@/api/iot.js";

const data = ref({status: 0})
const getFailTime = (fail) => {
  let minute = 0;
  let second = 0;
  minute = parseInt(fail / 60);
  second = fail % 60;
  console.log(minute, second)
  return minute + ':' + second.toString().padStart(2,'0')
}
const getData = async () => {
  await getReport().then((res) => {
    data.value = res.data
  })
  let i=0;
  for(i in data.value){
    data.value[i].fail_time = getFailTime(data.value[i].fail)
  }
}
const machine_list = ref({})
const getMachineList = async () => {
  await getNow().then((res) => {
    machine_list.value = res.data
  })
}
const start_time = ref()
const end_time = ref()
const machineName = ref('')
const postFilter = async () => {
  await postFilterReport({start: start_time.value, end: end_time.value, name: machineName.value}).then((res) => {
    data.value = res.data;
  })
  let i=0;
  for(i in data.value){
    data.value[i].fail_time = getFailTime(data.value[i].fail)
  }
}
onMounted(() => {
  getData();
  getMachineList();
})
</script>

<template>
  <div style="display: flex;flex-direction: row">
    <div style="display: flex;flex-direction: row;width: 70%;padding: 3rem 0 0 3rem;">
      <button type="button" class="btn btn-secondary" style="width: 10%"
              onclick="window.location.href='/admin/prod-report'">即時資訊
      </button>
      <button type="button" class="btn btn-primary" style="width: 10%;margin-left: 2rem;">歷史資訊</button>
      <button type="button" class="btn btn-secondary" style="width: 10%;margin-left: 2rem;" onclick="window.location.href='/admin/chart'">趨勢圖</button>
    </div>
  </div>
  <div style="display: flex;flex-direction: column">
    <div style="display: flex;flex-direction: row;width: 70%;padding: 1rem 0 0 3rem;">
      <div class="mb-3">
        <label for="id_machine">機台編號</label>
        <select class="form-select" id="id_machine" v-model="machineName">
          <option value="">選擇機器</option>
          <option v-for="i in machine_list" :value="i.name">{{i.name}}</option>
        </select>
      </div>
    </div>
    <div style="display: flex;flex-direction: row;width: 70%;padding: 1rem 0 0 3rem;">
      <div class="mb-3">
        <label for="id_begin_date">開始時間</label>
        <input type="datetime-local" class="form-control" id="id_begin_date" v-model="start_time"/>
      </div>
      <div class="mb-3 mx-3">
        <label for="id_end_date">結束時間</label>
        <input type="datetime-local" class="form-control" id="id_end_date" v-model="end_time"/>
      </div>
      <div class="col-lg-5 mt-4">
        <button type="button" class="btn btn-primary me-3" @click="postFilter">查詢</button>
        <button type="button" class="btn btn-outline-primary">匯出</button>
      </div>
    </div>
  </div>
  <div style="padding-left: 2%;">
    <table class="table" style="margin-top: 1rem; width: 96%">
      <thead>
      <tr>
        <th>機器編號</th>
        <th>生產開始時間</th>
        <th>生產結束時間</th>
        <th>機故時間</th>
        <th>完工數量</th>
        <th>不良品數量</th>
        <th>作業者</th>
      </tr>
      </thead>
      <tbody>
      <tr v-for="i in data">
        <td>{{i.name}}</td>
        <td>{{i.start_time}}</td>
        <td>{{i.end_time}}</td>
        <td>{{i.fail_time}}</td>
        <td>{{i.count}}</td>
        <td>-</td>
        <td>王大明</td>
      </tr>
      </tbody>
    </table>
  </div>
</template>

<style scoped>

</style>