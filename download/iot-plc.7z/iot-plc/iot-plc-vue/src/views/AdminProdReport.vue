<script setup>
import {computed, onMounted, ref} from "vue";
import {getNow, getReport} from "@/api/iot.js";

const getFailTime = (fail) => {
  let minute = 0;
  let second = 0;
  minute = parseInt(fail / 60);
  second = fail % 60;
  console.log(minute, second)
  return minute + ':' + second.toString().padStart(2,'0')
}
const data = ref({})
const getData = async () => {
  await getNow().then((res) => {
    data.value = res.data
  })
  let i=0;
  for(i in data.value){
    data.value[i].fail_time = getFailTime(data.value[i].fail)
  }
}
onMounted(() => {
  getData();
})
</script>

<template>
  <div style="display: flex;flex-direction: row">
    <div style="display: flex;flex-direction: row;width: 70%;padding: 3rem 0 0 3rem;">
      <button type="button" class="btn btn-primary" style="width: 10%">即時資訊</button>
      <button type="button" class="btn btn-secondary" style="width: 10%;margin-left: 2rem;" onclick="window.location.href='/admin/history'">歷史資訊</button>
      <button type="button" class="btn btn-secondary" style="width: 10%;margin-left: 2rem;" onclick="window.location.href='/admin/chart'" >趨勢圖</button>
    </div>
<!--    <div style="display: flex;flex-direction: row;width: 30%;padding-top: 3rem;">-->
<!--      <input type="text" class="form-control" style="width: 70%" placeholder="生產產品名稱"/>-->
<!--      <button type="button" class="btn btn-primary" style="width: 20%;margin-left: 1rem;">確認</button>-->
<!--    </div>-->
  </div>
<!--  <div style="display: flex;flex-direction: row">-->
<!--    <div style="display: flex;flex-direction: row;width: 70%;padding: 1rem 0 0 3rem;">-->
<!--      <span class="badge text-bg-success">溫度感測器：OK</span>-->
<!--      <span class="badge text-bg-danger">壓力感測器：Error</span>-->
<!--    </div>-->
<!--  </div>-->
  <div style="padding-left: 2%;">
    <table class="table" style="margin-top: 1rem; width: 96%">
      <thead>
        <tr>
          <th>機型名稱</th>
          <th>生產開始時間</th>
          <th>機故時間</th>
          <th>完工數量</th>
          <th>不良品數量</th>
          <th>作業者</th>
          <th>狀態</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="i in data">
          <td>{{i.name}}</td>
          <td>{{i.start_time}}</td>
          <td>{{i.fail_time}}</td>
          <td>{{i.count}}</td>
          <td>-</td>
          <td>王大明</td>
          <td>{{i.power === 0 || i.run === 0?'已停止':'進行中'}}</td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<style scoped>

</style>