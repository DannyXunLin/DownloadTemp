<script setup>

import logo from "@/assets/logo.png";
import RTBItem from "@/components/RTBItem.vue";
import RTBBtmBar from "@/components/RTBBtmBar.vue";
import {ref} from "vue";
import StatusLED from "@/components/StatusLED.vue";
import ProudWatch from "@/components/ProudWatch.vue";

const rtb_list = ref([])
const rtb_list_generate = () => {
  let i = 0;
  for (i = 0; i < 5; i++) {
    rtb_list.value.push(`RTB0${i}`)
  }
}
rtb_list_generate()

const data = ref({status: 0})
</script>

<template>
  <div style="padding: 3rem;">
    <h3>預計產量</h3>
    <table class="table" style="margin-top: 1rem; width: 96%">
      <thead>
      <tr>
        <th>機台名稱</th>
        <th>目前預計生產量</th>
        <th>修改預計生產量</th>
      </tr>
      </thead>
      <tbody>
      <tr>
        <td>A001</td>
        <td>2,000</td>
        <td><input type="number"> </td>
      </tr>
      </tbody>
    </table>
    <button type="button" class="btn btn-primary">確認修改</button>
  </div>
</template>

<style scoped>

</style>