<script setup>

import ActivationWatch from "@/components/ActivationWatch.vue";
</script>

<template>
<ActivationWatch :value=0 />
</template>

<style scoped>

</style>