<script setup>
import {ref} from "vue";
import {testLine} from "@/api/iot.js";

const pwd = ref("")
const msg = ref("")
const data = ref({})

const warning = async () => {
  msg.value = '警告訊息測試'
  await send()
}

const error = async () => {
  msg.value = '錯誤訊息測試'
  await send()
}

const send = async () => {
  data.value.msg = msg
  data.value.pwd = pwd
  await testLine(data.value).then((res) => {
    alert('發送成功')
  }).catch((err) => {
    alert(`發送失敗 ${err}`)
  })
}
</script>

<template>
  <div class="mb-3">
    <label for="id_pwd">密碼請參閱群組</label>
    <input type="password" class="form-control" v-model="pwd" id="id_pwd"/>
  </div>
  <button class="btn btn-warning" @click="warning">警告訊息測試</button>
  <button class="btn btn-danger" @click="error">錯誤訊息測試</button>
</template>

<style scoped>

</style>