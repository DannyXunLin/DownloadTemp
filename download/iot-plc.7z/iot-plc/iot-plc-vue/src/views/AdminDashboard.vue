<script setup>

import logo from "@/assets/logo.png";
import RTBItem from "@/components/RTBItem.vue";
import RTBBtmBar from "@/components/RTBBtmBar.vue";
import {computed, onBeforeUnmount, onMounted, ref} from "vue";
import StatusLED from "@/components/StatusLED.vue";
import ProudWatch from "@/components/ProudWatch.vue";
import {getNow} from "@/api/iot.js";

const rtb_list = ref()
const getRTBList = async () => {
  await getNow().then((res) => {
    rtb_list.value = res.data
  })
}

let date = new Date()
const date_str = ref('-------')

let URL = import.meta.env.VITE_WS_URL;
let socket = new WebSocket(URL)
const data = ref({})
const connectWebSocket = () => {
  socket.onopen = () => {
    console.log('WebSocket连接已建立');
  }

  socket.onmessage = (message) => {
    console.log(message.data)
    data.value = JSON.parse(message.data)
  }

  socket.onclose = () => {
    console.log('WebSocket连接已关闭');
  };
}
connectWebSocket()

let i = 0;
const message = ref('')
const sendSocket = () => {
  message.value = rtb_list.value[i].name;
  console.log(message.value)
  if (socket && socket.readyState === WebSocket.OPEN) {
    socket.send(message.value);
  } else {
    console.error('WebSocket is not open. ReadyState:', this.socket.readyState);
  }
  if (i >= rtb_list.value.length - 1) i = 0;
  else i++
}

const getAvailability = computed(() => {
  let avai = data.value.availability;
  return Math.round(avai * 100);
})

onBeforeUnmount(() => {
  if (socket) {
    socket.close()
  }
  clearInterval(socketInterval)
})

let socketInterval
let timeInterval
onMounted(() => {
  getRTBList();
  socketInterval = setInterval(sendSocket, 1000)
  timeInterval = setInterval(() => {
    date = new Date()
    date_str.value = `${date.getFullYear()}/${date.getMonth() + 1 >= 10 ? date.getMonth() + 1 : '0' + (date.getMonth() + 1)}/${date.getDate()}
      ${date.getHours() >= 10 ? date.getHours() : '0' + date.getHours()}:${date.getMinutes() >= 10 ? date.getMinutes() : '0' + date.getMinutes()}:${date.getSeconds() >= 10 ? date.getSeconds() : '0' + date.getSeconds()}`
  }, 1000)
})
</script>

<template>
  <div style="display: flex;">
    <div style="border-right: solid 1px #b5becb;width: 422px;padding-top: 20px;">
      <div style="height: 29px;margin-bottom: 20px;">
        <div class="Mask-group">
          <div class="logo-1">
            <img :src="logo" alt="logo"/>
          </div>
        </div>
        <div class="Vector-240"></div>
        <span class="WB">WB</span>
      </div>
      <div class="time">
        2024/04/17 下午2:50:57
      </div>
      <div class="station">
        <span id="station_title">
          站別：客戶定義的機台名稱Ａ
        </span>
      </div>
      <div class="rtb_group">
        <div class="second-value">溫度值：{{ data.temperature }} ˚C</div>
        <div class="second-value">壓力值：{{ data.pressure }} kg/cm²</div>
        <div class="second-line"></div>
      </div>
    </div>
    <div style="display: flex; flex-direction: column;">
      <div>
        <div class="center-second-title-bg">
          <span class="center-second-title">稼動率</span>
        </div>
        <div class="center-second-content-div">
          <div style="width: 100%; text-align: center">
            <span class="center-second-content-text">{{ getAvailability }}<span style="font-size: 36px;">%</span></span>
          </div>
        </div>
      </div>
      <div style="border-bottom: solid 1px #b5becb;">
        <div class="center-second-title-bg">
          <span class="center-second-title">目前產能</span>
          <span class="center-second-title" style="margin-left: 200px">|  CT</span>
        </div>
        <div class="center-second-content-div" style="display: flex; flex-direction: row; padding: 0px;">
          <div style="width: 50%; text-align: center">
            <span class="center-second-content-text" style="font-weight: normal;font-size: 126px;">{{ data.count }}<span
                style="font-size: 24px;">PCS</span></span>
          </div>
          <div style="width: 50%; text-align: center">
            <span class="center-second-content-text" style="font-weight: normal;font-size: 126px;">{{ data.cycle_time }}<span
                style="font-size: 24px;">Sec/PCS</span></span>
          </div>
        </div>
      </div>
      <div class="center-bottom">
        <StatusLED :status="data.status === 2?1:0" :color="'led-red'" name="設備異常"/>
        <StatusLED :status=0 :color="'led-yellow'" name="設備等待"/>
        <StatusLED :status="data.status === 3?1:0" :color="'led-yellow'" name="設備暫停"/>
        <StatusLED :status="data.status === 1?1:0" :color="'led-green'" name="設備運行"/>
      </div>
    </div>
    <div style="display: flex; flex-direction: column;border-left: solid 1px #b5becb;">
      <div class="center-second-title-bg" style="width: 361.5px;border-top-right-radius: 20px;padding-left: 15px;">
        <span class="center-second-title">生產監控站</span>
      </div>
      <div style="max-width: 360px;padding-left: 10px;">
        <ProudWatch :status='message === i.name?1:2' :name="i.name" v-for="i in rtb_list"/>
      </div>
    </div>
  </div>
</template>

<style scoped>
.logo-1 {
  width: 40px;
  height: 33px;
  flex-grow: 0;
}

.Mask-group {
  width: 40px;
  height: 40px;
  margin: 0 9px 0 25px;
  padding: 2px 0 5px;
  float: left;
}

.Vector-240 {
  width: 2px;
  height: 24px;
  margin: 8px 9px 0 0;
  background-color: #4f6483;
  float: left;
}

.WB {
  width: 41px;
  height: 29px;
  margin: 5px 290px 0 0;
  font-family: "Arial", serif;
  font-size: 24px;
  font-weight: bold;
  font-stretch: normal;
  font-style: normal;
  line-height: normal;
  letter-spacing: normal;
  text-align: left;
  color: #000;
  float: left;
}

.time {
  width: 291px;
  height: 29px;
  margin: 20px 106px 10px 25px;
  font-family: "Arial", serif;
  font-size: 24px;
  font-weight: bold;
  font-stretch: normal;
  font-style: normal;
  line-height: normal;
  letter-spacing: normal;
  text-align: left;
  color: #000C1D;
}

.station {
  width: 422px;
  height: 63px;
  margin: 10px 0 20px;
  padding: 17px 85px 17px 25px;
  background-color: #324258;
}

span#station_title {
  width: 312px;
  height: 29px;
  font-family: "Arial", serif;
  font-size: 24px;
  font-weight: bold;
  font-stretch: normal;
  font-style: normal;
  line-height: normal;
  letter-spacing: normal;
  text-align: left;
  color: #fff;
}

.rtb_group {
  margin-left: 25px;
  width: 395px;
  height: 520px;
}

.second-value {
  margin-bottom: 10px;
  font-family: "Arial", serif;
  font-size: 24px;
  font-weight: bold;
  font-stretch: normal;
  font-style: normal;
  line-height: normal;
  letter-spacing: normal;
  text-align: left;
  color: #808cad;
}

.second-line {
  width: 374px;
  height: 1px;
  margin: 20px 0px;
  //transform: rotate(-90deg);
  border: solid 1px #b5becb;
}

.center-second-title-bg {
  background: #d7dbe6;
  width: 676px;
  height: 63px;
  padding: 17px 0 17px 34px;
}

.center-second-title {
  color: #324258;
  font-weight: bold;
  font-family: "Arial", serif;
  font-size: 24px;
}

.center-second-content-div {
  padding: 47px;
}

.center-second-content-text {
  color: #4f6483;
  font-weight: bold;
  font-family: "Arial", serif;
  font-size: 96px;
}

.center-bottom {
  width: 655px;
  height: 100px;
  padding: 5px 37px 35px 65px;
  margin-top: 25px;
  border-radius: 20px;
  display: flex;
  flex-direction: row;
}
</style>