<script setup>
import RTBItem from "@/components/RTBItem.vue";
import {computed, onBeforeUnmount, onMounted, ref} from "vue";
import RTBBtmBar from "@/components/RTBBtmBar.vue";
import ActivationWatch from "@/components/ActivationWatch.vue";
import StatusLED from "@/components/StatusLED.vue";
import ProudWatch from "@/components/ProudWatch.vue";
import logo from '@/assets/logo.png'
import {getA, getNow} from "@/api/iot.js";

const rtb_list = ref()
const getRTBList = async () => {
  await getNow().then((res) => {
    rtb_list.value = res.data
  })
}

let date = new Date()
const date_str = ref('-------')

let URL = import.meta.env.VITE_WS_URL;
let socket = new WebSocket(URL)
const data = ref({})
const connectWebSocket = () => {
  socket.onopen = () => {
    console.log('WebSocket连接已建立');
  }

  socket.onmessage = (message) => {
    console.log(message.data)
    data.value = JSON.parse(message.data)
  }

  socket.onclose = () => {
    console.log('WebSocket连接已关闭');
  };
}
connectWebSocket()

let i = 0;
const message = ref('')
const sendSocket = () => {
  message.value = rtb_list.value[i].name;
  console.log(message.value)
  if (socket && socket.readyState === WebSocket.OPEN) {
    socket.send(message.value);
  } else {
    console.error('WebSocket is not open. ReadyState:', this.socket.readyState);
  }
  if(i >= rtb_list.value.length - 1) i = 0;
  else i++
}

const getAvailability = computed(() => {
  let avai = data.value.availability;
  return Math.round(avai * 100);
})

onBeforeUnmount(() => {
  if (socket) {
    socket.close()
  }
  clearInterval(socketInterval)
})

let socketInterval
let timeInterval
onMounted(() => {
  getRTBList();
  socketInterval = setInterval(sendSocket, 1000)
  timeInterval = setInterval(() => {
    date = new Date()
    date_str.value = `${date.getFullYear()}/${date.getMonth() + 1 >= 10 ? date.getMonth() + 1 : '0' + (date.getMonth() + 1)}/${date.getDate()}
      ${date.getHours() >= 10 ? date.getHours() : '0' + date.getHours()}:${date.getMinutes() >= 10 ? date.getMinutes() : '0' + date.getMinutes()}:${date.getSeconds() >= 10 ? date.getSeconds() : '0' + date.getSeconds()}`
  }, 1000)
})
</script>

<template>
  <div class="db-bg">
    <div class="db-left">
      <div style="height: 29px;margin-bottom: 20px;">
        <div class="Mask-group">
          <div class="logo-1">
            <img :src="logo" alt="logo"/>
          </div>
        </div>
        <div class="Vector-240"></div>
        <span class="WB">WB</span>
      </div>
      <div class="time">
        {{ date_str }}
      </div>
      <div class="station">
        <span id="station_title">
          站別：客戶定義的機台名稱Ａ
        </span>
      </div>
      <div class="rtb_group">
        <div class="second-value">溫度值：{{data.temperature}} ˚C</div>
        <div class="second-value">壓力值：{{data.pressure}} kg/cm²</div>
        <div class="second-line"></div>
<!--        <RTBItem :name="i.name" v-for="i in rtb_list"/>-->
      </div>
      <RTBBtmBar/>
    </div>
    <div class="db-center">
      <div class="activation">
        <div class="activation-title"><span class="activation-title-string">稼動率</span></div>
        <div class="activation-content">
          <div
              style="padding-top: 20px;margin-left: 24px;margin-right: 15px;display: inline-block;width: 250px;position: relative;top: -8rem;">
            <ActivationWatch :value="getAvailability"/>
          </div>
          <span class="activation-content-string">{{getAvailability}}</span><span
            class="activation-content-string-down">%</span></div>
      </div>
      <div class="activation" style="margin-top: 25px;">
        <div class="activation-title">
          <span class="activation-title-string">產能計數</span>
          <span class="activation-title-string" style="margin-left: 206px;">生產速度</span>
        </div>
        <div class="activation-content">
          <span class="activation-content-string">{{ data.count }}</span><span
            class="activation-content-string-down">PCS</span>
          <span class="activation-content-string">{{data.cycle_time}}</span><span
            class="activation-content-string-down">Sec/PCS</span>
        </div>
      </div>
      <div class="center-bottom">
        <StatusLED :status="data.status === 2?1:0" :color="'led-red'" name="設備異常"/>
        <StatusLED :status=0 :color="'led-yellow'" name="設備等待"/>
        <StatusLED :status="data.status === 3?1:0" :color="'led-yellow'" name="設備暫停"/>
        <StatusLED :status="data.status === 1?1:0" :color="'led-green'" name="設備運行"/>
      </div>
    </div>
    <div class="db-right">
      <div class="right-title">
        <span class="activation-title-string" style="margin-left: 20px;position: relative;top:20px;">生產監控站</span>
      </div>
      <div class="right-content">
        <ProudWatch :status='message === i.name?1:2' :name="i.name" v-for="i in rtb_list"/>
      </div>
    </div>
  </div>
</template>

<style scoped>
.db-bg {
  width: 100%;
  height: 864px;
  flex-grow: 0;
  padding: 33px 29px 33px 36px;
  background-image: linear-gradient(121deg, #3e4965, #232f50 100%);
  display: flex;
}

.db-left {
  width: 422px;
  height: 790px;
  margin: 0 25px 0 0;
  padding: 20px 0 18px;
  border-radius: 20px;
  background-image: linear-gradient(to bottom, #fff 33%, #d9efff 67%);
}


.logo-1 {
  width: 40px;
  height: 33px;
  flex-grow: 0;
}

.Mask-group {
  width: 40px;
  height: 40px;
  margin: 0 9px 0 25px;
  padding: 2px 0 5px;
  float: left;
}

.Vector-240 {
  width: 2px;
  height: 24px;
  margin: 8px 9px 0 0;
  background-color: #4f6483;
  float: left;
}

.WB {
  width: 41px;
  height: 29px;
  margin: 5px 296px 0 0;
  font-family: "Arial", serif;
  font-size: 24px;
  font-weight: bold;
  font-stretch: normal;
  font-style: normal;
  line-height: normal;
  letter-spacing: normal;
  text-align: left;
  color: #000;
  float: left;
}

.time {
  width: 291px;
  height: 29px;
  margin: 20px 106px 10px 25px;
  font-family: "Arial", serif;
  font-size: 24px;
  font-weight: bold;
  font-stretch: normal;
  font-style: normal;
  line-height: normal;
  letter-spacing: normal;
  text-align: left;
  color: #808cad;
}

.station {
  width: 422px;
  height: 63px;
  margin: 10px 0 20px;
  padding: 17px 85px 17px 25px;
  background-color: #416de0;
}

span#station_title {
  width: 312px;
  height: 29px;
  font-family: "Arial", serif;
  font-size: 24px;
  font-weight: bold;
  font-stretch: normal;
  font-style: normal;
  line-height: normal;
  letter-spacing: normal;
  text-align: left;
  color: #fff;
}

.rtb_group {
  margin-left: 25px;
  width: 395px;
  height: 520px;
}

.activation-title {
  width: 655px;
  height: 70px;
  padding: 22px 0 22px 28px;
  background-image: linear-gradient(to bottom, #546aa2, #354e8f);
  border-top-left-radius: 20px;
  border-top-right-radius: 20px;
}

.activation-content {
  width: 655px;
  height: 220px;
  padding: 0 0 6px;
  border-bottom-left-radius: 20px;
  border-bottom-right-radius: 20px;
  background-image: linear-gradient(to bottom, #fff, #d9efff);
}

.activation-title-string {
  width: 90px;
  height: 36px;
  font-family: "Arial", serif;
  font-size: 30px;
  font-weight: bold;
  font-stretch: normal;
  font-style: normal;
  line-height: normal;
  letter-spacing: normal;
  text-align: left;
  color: #fff;
}

.center-bottom {
  width: 655px;
  height: 160px;
  padding: 45px 37px 35px 65px;
  margin-top: 25px;
  border-radius: 20px;
  background-image: linear-gradient(to bottom, #fff, #d9efff);
}

.activation-content-string {
  width: 173px;
  height: 194px;
  margin: 20px 5px 0 31px;
  font-family: "Arial", serif;
  font-size: 160px;
  font-weight: 500;
  font-stretch: normal;
  font-style: normal;
  line-height: normal;
  letter-spacing: normal;
  text-align: left;
  color: #4f6483;
}

.activation-content-string-down {
  width: 21px;
  height: 29px;
  margin: 143px 24px 7px 5px;
  font-family: "Arial", serif;
  font-size: 24px;
  font-weight: bold;
  font-stretch: normal;
  font-style: normal;
  line-height: normal;
  letter-spacing: normal;
  text-align: left;
  color: #000c1d;
}

.right-content {
  width: 350px;
  height: 710px;
  margin: 0 0 0 25px;
  padding: 20px 0 18px;
  border-bottom-left-radius: 20px;
  border-bottom-right-radius: 20px;
  background-image: linear-gradient(to bottom, #fff 33%, #d9efff 67%);
}

.right-title {
  width: 350px;
  height: 80px;
  margin: 0 0 0 25px;
  border-top-left-radius: 20px;
  border-top-right-radius: 20px;
  background-image: linear-gradient(to bottom, #546aa2 0%, #354e8f);
}

.second-value {
  margin-bottom: 10px;
  font-family: "Arial", serif;
  font-size: 24px;
  font-weight: bold;
  font-stretch: normal;
  font-style: normal;
  line-height: normal;
  letter-spacing: normal;
  text-align: left;
  color: #808cad;
}

.second-line {
  width: 374px;
  height: 1px;
  margin: 20px 0px;
  //transform: rotate(-90deg);
  border: solid 1px #b5becb;
}
</style>