<script setup>

import logo from "@/assets/logo.png";
import RTBItem from "@/components/RTBItem.vue";
import RTBBtmBar from "@/components/RTBBtmBar.vue";
import {ref} from "vue";
import StatusLED from "@/components/StatusLED.vue";
import ProudWatch from "@/components/ProudWatch.vue";

const rtb_list = ref([])
const rtb_list_generate = () => {
  let i = 0;
  for (i = 0; i < 5; i++) {
    rtb_list.value.push(`RTB0${i}`)
  }
}
rtb_list_generate()

const data = ref({status: 0})
</script>

<template>
  <div style="padding: 3rem;">
    <h3>系統設定</h3>
    <h3>現在沒有設定。</h3>
  </div>
</template>

<style scoped>

</style>