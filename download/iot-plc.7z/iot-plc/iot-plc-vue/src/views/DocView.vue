<script setup>

import DocDetails from "@/components/DocDetails.vue";
</script>

<template>
  <DocDetails/>
</template>

<style scoped>

</style>