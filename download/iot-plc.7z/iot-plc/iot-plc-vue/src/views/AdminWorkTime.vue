<script setup>

import {getWorkTime} from "@/api/iot.js";
import {onMounted, ref} from "vue";

const time = ref('')
const getData = async () =>{
  await getWorkTime().then((res) => {
    time.value = res.data.time;
    time.value = parseFloat(time.value).toFixed(2)
  })
}
onMounted(() => {
  getData();
})
</script>

<template>
    <div style="display: flex;flex-direction: column;width: 70%;padding: 5rem 0 0 3rem;">
      <div class="mb-3 col-lg-4">
        <label for="id_worker">作業者</label>
        <select class="form-select" id="id_worker">
          <option value="1">王大明</option>
        </select>
      </div>
      <div class="mb-3 col-lg-4">
        <label for="id_time">工時</label>
        <input type="text" class="form-control" id="id_time" readonly v-model="time"/>
      </div>
    </div>
</template>

<style scoped>

</style>