<script setup>
import {computed, onMounted, ref, watch} from "vue";
import {getNow, getReport, postFilterReport, postGetData} from "@/api/iot.js";
import {Bar} from 'vue-chartjs'
import {Chart as ChartJS} from 'chart.js/auto'
import {Title, Tooltip, Legend, BarElement, CategoryScale, LinearScale} from 'chart.js'

const machineName = ref('')
const data = ref({})
const chart_data = ref({labels: [], datasets: [{label: '個數', data: []}]})
const chart_data_a = ref({labels: [], datasets: [{label: '稼動率', data: []}]})
const chart_data2 = ref({labels: [], datasets: [{data: []}]})
const chart_data2_a = ref({labels: [], datasets: [{data: []}]})
const chart_option = ref({responsive: true})
let recalc = 0
const getData = async () => {
  await postGetData({name: machineName.value}).then((res) => {
    data.value = res.data
  })
  chart_data.value = {labels: [], datasets: [{label: '個數', data: []}]}
  chart_data_a.value = {labels: [], datasets: [{label: '稼動率', data: []}]}
  let i = 0;
  for (i in data.value) {
    chart_data.value.labels.push(data.value[i]._id.month + '/' + data.value[i]._id.day + ' ' + data.value[i]._id.hour)
    chart_data_a.value.labels.push(data.value[i]._id.month + '/' + data.value[i]._id.day + ' ' + data.value[i]._id.hour)
    chart_data.value.datasets[0].data.push(data.value[i].maxCount)
    chart_data_a.value.datasets[0].data.push(data.value[i].maxAvailability*100)
  }
  chart_data2.value = chart_data.value
  chart_data2_a.value = chart_data_a.value
  recalc += 1
}

const comp_chart_data = computed(() => {
  let a = recalc
  let data = {}
  data = chart_data2.value
  return data
})

const comp_chart_data_a = computed(() => {
  let a = recalc
  let data = {}
  data = chart_data2_a.value
  return data
})

const comp_chart_option = computed(() => {
  return chart_option.value
})

const machine_list = ref({})
const getMachineList = async () => {
  await getNow().then((res) => {
    machine_list.value = res.data
  })
}
watch(machineName, (n) => {
  getData();
})
onMounted(() => {
  ChartJS.register(Title, Tooltip, Legend, BarElement, CategoryScale, LinearScale)
  getMachineList();
})
</script>

<template>
  <div style="display: flex;flex-direction: row">
    <div style="display: flex;flex-direction: row;width: 70%;padding: 3rem 0 0 3rem;">
      <button type="button" class="btn btn-secondary" style="width: 10%"
              onclick="window.location.href='/admin/prod-report'">即時資訊
      </button>
      <button type="button" class="btn btn-secondary" style="width: 10%;margin-left: 2rem;"
              onclick="window.location.href='/admin/history'">歷史資訊
      </button>
      <button type="button" class="btn btn-primary" style="width: 10%;margin-left: 2rem;">趨勢圖</button>
    </div>
  </div>
  <div style="display: flex;flex-direction: column">
    <div style="display: flex;flex-direction: row;width: 70%;padding: 1rem 0 0 3rem;">
      <div class="mb-3">
        <label for="id_machine">機台編號</label>
        <select class="form-select" id="id_machine" v-model="machineName">
          <option value="">選擇機器</option>
          <option v-for="i in machine_list" :value="i.name">{{ i.name }}</option>
        </select>
      </div>
    </div>
  </div>
  <div style="padding-left: 2%;">
    <div style="display: flex;">
      <div style="width: 50%">
        <h3>生產個數</h3>
        <Bar
            id="my-chart-id"
            :data="comp_chart_data"
            :options="comp_chart_option"
        />
      </div>
      <div style="width: 50%">
        <h3>稼動率</h3>
        <Bar
            id="my-chart-id"
            :data="comp_chart_data_a"
            :options="comp_chart_option"
        />
      </div>
    </div>
  </div>
</template>

<style scoped>

</style>