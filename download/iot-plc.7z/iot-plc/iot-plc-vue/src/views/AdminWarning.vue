<script setup>
import {onMounted, ref} from "vue";
import {getError, getNow, postFilterError} from "@/api/iot.js";

const machine_list = ref({})
const getMachineList = async () => {
  await getNow().then((res) => {
    machine_list.value = res.data
  })
}

const data = ref({})
const getData = async () => {
  await getError().then((res) => {
    data.value = res.data
  }).catch((err) => console.log(err))
}

const start_time = ref()
const end_time = ref()
const machineName = ref('')
const getFilterData = async () => {
  await postFilterError({start: start_time.value, end: end_time.value, name: machineName.value}).then((res) => {
    data.value = res.data
  })
}

onMounted(() => {
  getMachineList();
  getData();
})
</script>

<template>
  <div style="padding: 3rem;">
    <h3>異常訊息</h3>
    <div class="mb-3 col-lg-1">
      <label for="id_machine">機台編號</label>
      <select id="id_machine" class="form-select" v-model="machineName">
        <option value="">選擇機器</option>
        <option v-for="i in machine_list" :value="i.name">{{i.name}}</option>
      </select>
    </div>
    <div style="display: flex;">
      <div class="mb-3 col-lg-2">
        <label for="id_begin_time">開始時間</label>
        <input type="datetime-local" id="id_begin_time" class="form-control" v-model="start_time"/>
      </div>
      <div class="mb-3 col-lg-2 mx-3">
        <label for="id_end_time">結束時間</label>
        <input type="datetime-local" id="id_end_time" class="form-control" v-model="end_time"/>
      </div>
      <div class="mb-3 pt-4">
        <button type="button" class="btn btn-primary" @click="getFilterData">查詢</button>
      </div>
    </div>
    <table class="table" style="margin-top: 1rem; width: 96%">
      <thead>
      <tr>
        <th>機台名稱</th>
        <th>時間</th>
        <th>異常說明</th>
      </tr>
      </thead>
      <tbody>
      <tr v-for="i in data">
        <td>{{i.name}}</td>
        <td>{{i.timestamp}}</td>
        <td>{{i.error}}</td>
      </tr>
      </tbody>
    </table>
  </div>
</template>

<style scoped>

</style>