<script setup>
import '@/assets/main.css';
</script>

<template>
  <router-view></router-view>
</template>

<style scoped>
</style>
