const adminLayout = {
    path: '/admin',
    component: () => import('@/components/AdminLayout.vue'),
    redirect: '/admin/dashboard',
    children:[
        {path: 'dashboard', component: () => import('@/views/AdminDashboard.vue'), name: 'AdminDashboard'},
        {path: 'worktime', component: () => import('@/views/AdminWorkTime.vue'), name: 'Worktime'},
        {path: 'prod-report', component: () => import('@/views/AdminProdReport.vue'), name: 'ProdReport'},
        {path: 'history', component: () => import('@/views/AdminHistory.vue'), name: 'History'},
        {path: 'warning', component: () => import('@/views/AdminWarning.vue'), name: 'Warning'},
        {path: 'expect', component: () => import('@/views/AdminExpect.vue'), name: 'Expect'},
        {path: 'setting', component: () => import('@/views/AdminSetting.vue'), name: 'Setting'},
        {path: 'chart', component: () => import('@/views/AdminChart.vue'), name: 'Chart'}
    ]
}

export default adminLayout;