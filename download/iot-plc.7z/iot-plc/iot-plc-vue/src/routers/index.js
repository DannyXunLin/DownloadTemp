import {createRouter, createWebHistory} from "vue-router";
import {jwtDecode} from "jwt-decode";
import adminLayout from "@/routers/admin.js";

const router = createRouter({
    history: createWebHistory(),
    routes: [
        {path: '/', component: () => import('@/views/Dashboard.vue'), name: 'Dashboard'},
        {path: '/watch', component: () => import('@/views/WatchTest.vue'), name: 'Watch'},
        {path: '/line-test', component: () => import('@/views/LineTest.vue'), name: 'LineTest'},
        adminLayout
    ]
})

// router.beforeEach((to) => {
//     if (to.name !== 'Login' && localStorage.getItem('login') !== '1') {
//         try {
//             const jwt = localStorage.getItem('accessToken')
//             if (jwt === null) return {name: 'Login'}
//             jwtDecode(jwt);
//             localStorage.setItem('login', '1')
//             return to
//         } catch (err) {
//             console.log(err.message)
//             return {name: 'Login'}
//         }
//     }
// })

export default router;