<script setup>
import {computed} from "vue";

const props = defineProps(['state', 'name'])

const getString = computed(() => {
  return props.name
})
</script>

<template>
  <div class="rtb_item">
    <div class="rtb_green"></div>
    <span class="rtb_str">{{getString}}</span>
  </div>
</template>

<style scoped>
.rtb_item {
  margin-bottom: 25px;
  width: 200px;
  height: 31px;
}

.rtb_green {
  background-color: #04df00;
  width: 20px;
  height: 20px;
  border-radius: 50%;
  display: inline-block;
}

.rtb_str{
  font-family: "Arial",serif;
  font-size: 24px;
  display: inline-block;
  margin-left: 10px;
}
</style>