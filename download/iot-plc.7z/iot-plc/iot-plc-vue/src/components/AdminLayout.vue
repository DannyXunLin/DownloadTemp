<script setup>
import Home from "@/components/Icon/Home.vue";
import {computed} from "vue";
import WorkTime from "@/components/Icon/WorkTime.vue";
import ProdReport from "@/components/Icon/ProdReport.vue";
import Warning from "@/components/Icon/Warning.vue";
import Expect from "@/components/Icon/Expect.vue";
import Setting from "@/components/Icon/Setting.vue";
const props = defineProps(['active'])
</script>

<template>
  <div class="_PC_">
    <div class="second-bg">
      <router-view></router-view>
    </div>
    <div class="bottom">
      <router-link to="/admin/dashboard" active-class="active" class="nav-item" v-slot="{isActive}">
        <Home class="nav-icon" :active="isActive"/>
        <span>系統首頁</span>
      </router-link>
      <router-link to="/admin/worktime" active-class="active" class="nav-item" v-slot="{isActive}">
        <WorkTime class="nav-icon" :active="isActive"/>
        <span>人員工時</span>
      </router-link>
      <router-link to="/admin/prod-report" active-class="active" class="nav-item" v-slot="{isActive}">
        <ProdReport class="nav-icon" :active="isActive"/>
        <span>生產報表</span>
      </router-link>
      <router-link to="/admin/warning" active-class="active" class="nav-item" v-slot="{isActive}">
        <Warning class="nav-icon" :active="isActive"/>
        <span>異常訊息</span>
      </router-link>
<!--      <router-link to="/admin/expect" active-class="active" class="nav-item" v-slot="{isActive}">-->
<!--        <Expect class="nav-icon" :active="isActive"/>-->
<!--        <span>預計產量</span>-->
<!--      </router-link>-->
      <router-link to="/admin/setting" active-class="active" class="nav-item" v-slot="{isActive}">
        <Setting class="nav-icon" :active="isActive"/>
        <span>系統設定</span>
      </router-link>
    </div>
  </div>
</template>

<style scoped>
._PC_ {
  width: 100%;
  height: 864px;
  flex-grow: 0;
  padding: 27px 30px 0 30px;
  background-image: linear-gradient(125deg, #7d8ab8 -1%, #354775 99%);
}

.second-bg {
  width: 100%;
  height: 697px;
  background-color: #efefef;
  border-radius: 20px 20px 0 0;
  border-bottom: solid 2px #8793a5;
}

.bottom {
  width: 100%;
  height: 140px;
  background-image: linear-gradient(to bottom, #f2f2f2, #c0c8dc);
  padding-top: 25px;
  padding-left: 250px;
  padding-right: 250px;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
}
.nav-item{
  display: flex;
  width: 60px;
  flex-direction: column;
  align-items: center;
  text-decoration:none;
}
.nav-item span {
  width: 80px;
  height: 24px;
  flex-grow: 0;
  margin: 12.5px 0 0;
  font-family: Inter;
  font-size: 20px;
  font-weight: bold;
  font-stretch: normal;
  font-style: normal;
  line-height: normal;
  letter-spacing: normal;
  text-align: left;
  color: #324258;
}
.nav-item.active span {
  width: 80px;
  height: 24px;
  flex-grow: 0;
  margin: 12.5px 0 0;
  font-family: Inter;
  font-size: 20px;
  font-weight: bold;
  font-stretch: normal;
  font-style: normal;
  line-height: normal;
  letter-spacing: normal;
  text-align: left;
  color: #0057d0;
}
</style>