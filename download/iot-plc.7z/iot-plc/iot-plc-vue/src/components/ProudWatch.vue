<script setup>
import {computed} from "vue";

const props = defineProps(['status', 'name'])

const getStatus = computed(() => {
  const status = props.status
  return status === 1;
})

const getName = computed(() => {
  return props.name
})
</script>

<template>
<div :class="{'now-watch': getStatus, 'disable-watch': !getStatus}">
  <div :class='{"green-led":getStatus, "disable-led": !getStatus}'></div>
  <span class="watch-text">{{getName}}</span>
</div>
</template>

<style scoped>
.now-watch {
  width: 90%;
  height: 60px;
  margin: 10px 9px;
  padding: 12px 75px 17px 19px;
  border-radius: 15px;
  background-image: linear-gradient(to right, #00928a, #00736c);
}

.disable-watch {
  width: 90%;
  height: 60px;
  margin: 10px 9px;
  padding: 12px 72px 17px 19px;
  border-radius: 15px;
  background-image: linear-gradient(to right, #aeaeae, #7c7c7c);
}

.green-led {
  width: 20px;
  height: 20px;
  margin: 8px 10px 3px 0;
  background-color: #04df00;
  border-radius: 50%;
  display: inline-block;
}

.disable-led {
  width: 20px;
  height: 20px;
  margin: 8px 10px 3px 0;
  background-color: #626262;
  border-radius: 50%;
  display: inline-block;
}

.watch-text {
  width: 106px;
  height: 31px;
  margin: 0 0 0 10px;
  font-family: "Arial", serif;
  font-size: 26px;
  font-stretch: normal;
  font-style: normal;
  line-height: normal;
  letter-spacing: normal;
  text-align: left;
  color: #fff;
  display: inline-block;
}
</style>