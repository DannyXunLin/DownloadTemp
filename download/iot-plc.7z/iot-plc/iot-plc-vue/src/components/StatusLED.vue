<script setup>
import {computed} from "vue";

const props = defineProps(['name', 'status', 'color'])

const getName = computed(() => {
  return props.name
})

const getStatus = computed(() => {
  return props.status === 1;
})

const getColor = computed(() => {
  return props.color;
})
</script>

<template>
  <div style="display: inline-block;">
    <div class="g"  v-show="getColor === 'led-green'">
      <div :class="{'led': !getStatus, 'led-green': getStatus}"></div>
    </div>
    <div class="y"  v-show="getColor === 'led-yellow'">
      <div :class="{'led': !getStatus, 'led-yellow': getStatus}"></div>
    </div>
    <div class="r"  v-show="getColor === 'led-red'">
      <div :class="{'led': !getStatus, 'led-red': getStatus}"></div>
    </div>
  <span class="led-label">{{getName}}</span>
  </div>
</template>

<style scoped>
.led {
  width: 36px;
  height: 36px;
  background-color: #b7b7b7;
  border-radius: 50%;
  border: 7px solid #dcdcdc;
  margin-left: 30px;
}

.led-green {
  width: 36px;
  height: 36px;
  background-image: radial-gradient(circle at 50% 50%, #04df00, #03a000 71%);;
  border-radius: 50%;
  border: 7px solid #dcdcdc;
  margin-left: 30px;
}

.led-yellow {
  width: 36px;
  height: 36px;
  background-image: radial-gradient(circle at 50% 50%, #ffc73a, #ffcd39 71%);;
  border-radius: 50%;
  border: 7px solid #dcdcdc;
  margin-left: 30px;
}

.led-red {
  width: 36px;
  height: 36px;
  background-image: radial-gradient(circle at 50% 50%, #ff4f39, #ff4f39 71%);;
  border-radius: 50%;
  border: 7px solid #dcdcdc;
  margin-left: 30px;
}

.led-label {
  width: 96px;
  height: 29px;
  margin: 10px 42px 0 0;
  font-family: "Arial", serif;
  font-size: 24px;
  font-weight: bold;
  font-stretch: normal;
  font-style: normal;
  line-height: normal;
  letter-spacing: normal;
  text-align: left;
  color: #929292;
}
</style>