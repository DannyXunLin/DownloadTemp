<script setup>
import WifiOn from '@/assets/wifi-on.svg'
</script>

<template>
<div class="left_btm_bar">
  <div class="status">
  <div class="rtb_green"></div>
    <div class="rtb_yellow"></div>
    <div class="rtb_red"></div>
    <div class="split_line"></div>
    <img :src="WifiOn" alt="wifi-on" style="position: relative;top:-5px;"/>
  </div>
</div>
</template>

<style scoped>
.status{
  margin-left: 180px;
}
.left_btm_bar{
  width: 370px;
  height: 52px;
  margin-left: 25px;
  border-radius: 10px;
  background-color: #4b4b4b;
}
.rtb_green {
  background-color: #04df00;
  width: 20px;
  height: 20px;
  border-radius: 50%;
  margin-right: 20px;
  display: inline-block;
}
.rtb_red {
  background-color: #ff512b;
  width: 20px;
  height: 20px;
  border-radius: 50%;
  margin-right: 20px;
  display: inline-block;
}
.rtb_yellow {
  background-color: #ffc700;
  width: 20px;
  height: 20px;
  border-radius: 50%;
  margin-right: 20px;
  display: inline-block;
}
.split_line{
  width: 2px;
  height: 30px;
  margin: 5px 19px 5px 9px;
  background-color: #fff;
  position: relative;
  top: 10px;
  display: inline-block;
}
</style>