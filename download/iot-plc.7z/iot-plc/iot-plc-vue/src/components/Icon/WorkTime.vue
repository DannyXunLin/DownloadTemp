<script setup>
import {computed} from "vue";

const props = defineProps(['active'])
const fillcolor = computed(() => {
  return props.active?'#0057d0':'#324258'
})
</script>

<template>
  <svg width="60" height="50" viewBox="0 0 60 50" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path
        d="M34.5342 47.2516C47.0301 47.2516 57.16 37.1217 57.16 24.6258C57.16 12.1299 47.0301 2 34.5342 2C22.0384 2 11.9084 12.1299 11.9084 24.6258C11.9084 27.4118 12.412 30.0801 13.333 32.5448"
        :stroke="fillcolor" stroke-width="4" stroke-linecap="round"/>
    <path d="M14.7036 39.5895L2.31661 29.1367L22.6084 25.4399L14.7036 39.5895Z" :fill="fillcolor"/>
    <path d="M34.5342 15.0992V27.0075L39.2975 32.9617" :stroke="fillcolor" stroke-width="4" stroke-linecap="round"/>
  </svg>
</template>

<style scoped>

</style>