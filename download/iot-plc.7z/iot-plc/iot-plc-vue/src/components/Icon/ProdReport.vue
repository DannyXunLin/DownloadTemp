<script setup>
import {computed} from "vue";

const props = defineProps(['active'])
const fillcolor = computed(() => {
  return props.active ? '#0057d0' : '#324258'
})
</script>

<template>
  <svg width="51" height="51" viewBox="0 0 51 51" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path
        d="M33.6988 6.9819H45.2965C46.1801 6.9819 46.8965 7.69825 46.8965 8.5819V47.275C46.8965 48.1587 46.1801 48.875 45.2965 48.875H5.99648C5.11283 48.875 4.39648 48.1587 4.39648 47.275V8.5819C4.39648 7.69825 5.11283 6.9819 5.99648 6.9819H18.6375"
        :stroke="fillcolor" stroke-width="4"/>
    <mask id="path-2-inside-1_37_385" fill="white">
      <path
          d="M15.6453 2.4C15.6453 1.07452 16.7198 0 18.0453 0H33.2453C34.5708 0 35.6453 1.07452 35.6453 2.4V10.837C35.6453 11.2788 35.2871 11.637 34.8453 11.637H16.4453C16.0034 11.637 15.6453 11.2788 15.6453 10.837V2.4Z"/>
    </mask>
    <path
        d="M15.6453 2.4C15.6453 1.07452 16.7198 0 18.0453 0H33.2453C34.5708 0 35.6453 1.07452 35.6453 2.4V10.837C35.6453 11.2788 35.2871 11.637 34.8453 11.637H16.4453C16.0034 11.637 15.6453 11.2788 15.6453 10.837V2.4Z"
        :stroke="fillcolor" stroke-width="8" mask="url(#path-2-inside-1_37_385)"/>
    <path d="M15.6453 19.7826H35.6453" :stroke="fillcolor" stroke-width="4" stroke-linecap="round"
          stroke-linejoin="round"/>
    <path d="M15.6453 28.6424H35.6453" :stroke="fillcolor" stroke-width="4" stroke-linecap="round"
          stroke-linejoin="round"/>
    <path d="M15.6453 37.9511H35.6453" :stroke="fillcolor" stroke-width="4" stroke-linecap="round"
          stroke-linejoin="round"/>
  </svg>
</template>

<style scoped>

</style>