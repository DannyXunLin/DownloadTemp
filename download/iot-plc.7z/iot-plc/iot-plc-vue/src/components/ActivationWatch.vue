<script setup>
import bg from '@/assets/watch-bg.png';
import pointer from '@/assets/watch-pointer.png';
import {computed, onMounted, watch} from "vue";

const props = defineProps(['value'])

const movePointer = (d) => {
  const f = document.querySelector(".ra");
  f.setAttribute("style",`transform: rotate(${d}deg);`);
}
const getValue = computed(() => {
  return -80 + 160 * (props.value / 100)
})
onMounted(() => {
  movePointer(0)
})
watch(getValue, (n) => {
  movePointer(n)
}, {deep: true})
</script>

<template>
  <div class="cdd">
    <!-- 指針 -->
    <img class="r" :src="bg" alt="bg">
    <img class="ra" :src="pointer" alt="point">
  </div>
</template>

<style scoped>
.cdd {
  position: relative;
  width: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
}

.r {
  position: absolute;
  top: 0;
  left: 0;
  width: 304px;
}

.ra {
  position: absolute;
  width: 35px;
  left: 8.5rem;
  top: 4rem;
  transform: rotate(-90deg);
  transform-origin: bottom;
  animation: speeding 5s infinite alternate;
}
</style>
