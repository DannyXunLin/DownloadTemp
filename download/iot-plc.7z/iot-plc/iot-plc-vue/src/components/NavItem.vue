<script setup>
import Home from "@/components/Icon/Home.vue";
import {computed} from "vue";
const props = defineProps(['active'])
const svg_color = computed(() => {
  return props.active?'#0057d0':"#324258"
})
</script>

<template>
  <div class="nav-item">
    <Home :fill="svg_color"/>
    <span>系統首頁</span>
  </div>
</template>

<style scoped>
.nav-item{
  display: flex;
  width: 60px;
  flex-direction: column;
  align-items: center;
}
.nav-item span {
  width: 80px;
  height: 24px;
  flex-grow: 0;
  margin: 12.5px 0 0;
  font-family: Inter;
  font-size: 20px;
  font-weight: bold;
  font-stretch: normal;
  font-style: normal;
  line-height: normal;
  letter-spacing: normal;
  text-align: left;
  color: #0057d0;
}
.active{
  fill: #ff0000
}
</style>